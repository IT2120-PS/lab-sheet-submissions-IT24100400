setwd("C:\\Users\\it24100400\\Desktop\\IT24100400")
getwd()
branch_data <- read.table("Exercise.txt",header = TRUE, sep = ",")
